// Retired: shared data now lives at the top of site.js (single-script architecture).
// This file is kept only to avoid breaking old cached references.
