// Superseded: Nomad now uses data.js + site.js (multi-page architecture).
// This file is kept only to avoid breaking old cached references.
